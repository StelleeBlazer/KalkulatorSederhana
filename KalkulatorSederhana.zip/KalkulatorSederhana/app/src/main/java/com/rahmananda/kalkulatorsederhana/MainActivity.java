package com.rahmananda.kalkulatorsederhana;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private EditText edtInput1,edtInput2;
    private TextView tvHasil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtInput1 = findViewById(R.id.btn_input1);
        edtInput2 = findViewById(R.id.btn_input2);
        tvHasil = findViewById(R.id.tvhasil);
    }

    public void aksiKali(View v){
        aksiHitung("*");

    }
    public void aksiBagi(View v){
        aksiHitung("/");

    }
    public void aksiTambah(View v){
        aksiHitung("+");

    }
    public void aksiKurang(View v){
        aksiHitung("-");

    }


    public void aksiHitung(String aritmatika){
        String angka1 = edtInput1.getText().toString();
        String angka2 = edtInput2.getText().toString();

        if (TextUtils.isEmpty(angka1)){
            edtInput1.setError("Inputan Tidak Boleh Kosong");
        }else if (TextUtils.isEmpty(angka2)){
            edtInput2.setError("Inputan Tidak Boleh Kosong");
        }else{
            double a1 = Double.parseDouble(angka1);
            double a2 = Double.parseDouble(angka2);
            double hasil = 0;

            switch (aritmatika){
                case "*":
                    hasil = a1 * a2;
                    break;
                case "/":
                    hasil = a1 / a2;
                    break;
                case "+":
                    hasil = a1 + a2;
                    break;
                case "-":
                    hasil = a1 - a2;
                    break;
            }
            DecimalFormat hasildesimal = new DecimalFormat("0.###");
            tvHasil.setText(hasildesimal.format(hasil));

        }

    }

}
